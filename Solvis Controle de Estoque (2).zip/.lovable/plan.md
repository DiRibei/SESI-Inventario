## Objetivo
Quando um colaborador deixa de possuir um item (por remoção do cadastro ou por edição manual), o item deve voltar automaticamente para o estoque: `colaborador` vazio e `status = "Disponível"`.

## Escopo
- Ativos principais (`EstoqueSolvis` — Notebooks/Desktops).
- Periféricos (`peripheral_items`).
- Peças ficam de fora (não têm colaborador vinculado).

## Comportamentos

### 1. Remoção de colaborador (AdminColaboradores)
Fluxo em `src/pages/AdminColaboradores.tsx > handleDelete`:
1. Antes de deletar, contar itens vinculados ao nome do colaborador:
   - `EstoqueSolvis` onde `"Colaborador" = nome`
   - `peripheral_items` onde `colaborador = nome`
2. Abrir `AlertDialog` de confirmação:
   > "Remover **{nome}**? **X notebook(s)** e **Y periférico(s)** serão liberados automaticamente para o estoque (status → Disponível)."
3. Ao confirmar:
   - `UPDATE EstoqueSolvis SET "Colaborador"=NULL, "Status"='Disponível', "Atualizado_Em"=now() WHERE "Colaborador"=nome`
   - `UPDATE peripheral_items SET colaborador=NULL, status='Disponível' WHERE colaborador=nome`
   - Registrar entradas no histórico (`logAuditChanges`) para cada ativo alterado, autor = usuário atual, motivo implícito "Colaborador removido".
   - Deletar o colaborador.
   - Toast: "Colaborador removido. Z item(ns) liberado(s)."

### 2. Edição de ativo — limpar Colaborador
Em `src/components/AssetEditModal.tsx`:
- No `ColaboradorCombobox.onChange`, se o novo valor for vazio E o status atual não for terminal (`Vendido`, `Retirado`), setar `status = "Disponível"` no mesmo `setForm`.
- Não sobrescrever se o usuário já escolheu outro status terminal manualmente.

### 3. Edição de periférico — limpar Colaborador
Em `src/pages/Perifericos.tsx` (modal de edição, ~linha 195-230):
- No `onChange` do `ColaboradorCombobox` do form, se vazio → `status = "Disponível"`.

## Detalhes técnicos
- Usar `supabase` já importado em cada arquivo.
- Contagens: `.select("Patrimônio", { count: "exact", head: true }).eq(...)`.
- Confirmação: usar `AlertDialog` do shadcn (já usado no projeto) em vez de `window.confirm`.
- Auditoria: reutilizar `logAuditChanges` de `@/lib/api` iterando pelos ativos afetados (fetch antes do update para capturar valores antigos).

## Arquivos alterados
- `src/pages/AdminColaboradores.tsx` — nova confirmação + cascata.
- `src/components/AssetEditModal.tsx` — auto-toggle no combobox.
- `src/pages/Perifericos.tsx` — auto-toggle no combobox.
