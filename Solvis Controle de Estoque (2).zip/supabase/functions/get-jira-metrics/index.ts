const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface JiraIssue {
  key: string;
  fields: {
    summary: string;
    status: { name: string };
    priority: { name: string };
    assignee: { displayName: string } | null;
    created: string;
    resolutiondate: string | null;
    issuetype: { name: string };
    components: { name: string }[];
    description?: { content?: Array<{ content?: Array<{ text?: string }> }> } | string | null;
    // Custom fields — will be discovered dynamically
    [key: string]: unknown;
  };
}

interface JiraSearchResponse {
  startAt: number;
  maxResults: number;
  total: number;
  issues: JiraIssue[];
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const JIRA_BASE_URL = Deno.env.get("JIRA_BASE_URL");
    const JIRA_EMAIL = Deno.env.get("JIRA_EMAIL");
    const JIRA_API_TOKEN = Deno.env.get("JIRA_API_TOKEN");
    const JIRA_PROJECT_KEY = Deno.env.get("JIRA_PROJECT_KEY");

    if (!JIRA_BASE_URL || !JIRA_EMAIL || !JIRA_API_TOKEN || !JIRA_PROJECT_KEY) {
      return new Response(
        JSON.stringify({ error: "Missing Jira configuration secrets" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch all issues using pagination
    const allIssues: JiraIssue[] = [];
    let startAt = 0;
    const maxResults = 100;
    let total = 1; // will be updated on first call

    // Normalize base URL — remove trailing slash
    const baseUrl = JIRA_BASE_URL.replace(/\/+$/, "");

    while (startAt < total) {
      const jql = encodeURIComponent(`project = ${JIRA_PROJECT_KEY} ORDER BY created DESC`);
      const fields = encodeURIComponent("summary,status,priority,assignee,created,resolutiondate,issuetype,components,description,customfield_10010,customfield_10002,customfield_10060,customfield_10061,customfield_10068,reporter");
      const url = `${baseUrl}/rest/api/3/search/jql?jql=${jql}&startAt=${startAt}&maxResults=${maxResults}&fields=${fields}`;

      console.log("Fetching Jira URL:", url.split("?")[0]);

      const authHeader = btoa(`${JIRA_EMAIL}:${JIRA_API_TOKEN}`);

      const response = await fetch(url, {
        headers: {
          Authorization: `Basic ${authHeader}`,
          Accept: "application/json",
        },
      });

      const responseText = await response.text();

      if (!response.ok) {
        console.error("Jira API error:", response.status, responseText.substring(0, 500));
        return new Response(
          JSON.stringify({ error: "Jira API request failed", status: response.status, detail: responseText.substring(0, 300) }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      let data: JiraSearchResponse;
      try {
        data = JSON.parse(responseText);
      } catch {
        console.error("Jira returned non-JSON:", responseText.substring(0, 300));
        return new Response(
          JSON.stringify({ error: "Jira returned non-JSON response", detail: responseText.substring(0, 300) }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      total = data.total;
      allIssues.push(...data.issues);
      startAt += maxResults;
    }

    // Helper: extract plain text from Jira ADF (Atlassian Document Format)
    function extractAdfText(desc: unknown): string {
      if (!desc) return "";
      if (typeof desc === "string") return desc;
      if (typeof desc === "object" && desc !== null && "content" in desc) {
        const adf = desc as { content?: Array<{ content?: Array<{ text?: string }> }> };
        return (adf.content ?? [])
          .flatMap((block) => (block.content ?? []).map((inline) => inline.text ?? ""))
          .join(" ")
          .trim();
      }
      return "";
    }

    // Helper: extract custom field value (tries string, object with value/name)
    function extractCustomField(val: unknown): string {
      if (!val) return "";
      if (typeof val === "string") return val;
      if (typeof val === "object" && val !== null) {
        const obj = val as Record<string, unknown>;
        if (obj.requestType && typeof obj.requestType === "object") {
          return (obj.requestType as Record<string, unknown>).name as string ?? "";
        }
        return String(obj.value ?? obj.name ?? obj.displayName ?? "");
      }
      return String(val);
    }

    // Helper: parse structured fields from description text
    function parseDescription(text: string): { setor: string; email: string; tipo: string; categoria: string } {
      const result = { setor: "", email: "", tipo: "", categoria: "" };
      if (!text) return result;
      const patterns: Array<{ key: keyof typeof result; regex: RegExp }> = [
        { key: "setor", regex: /Setor\s*:\s*(.+?)(?:\s{2,}|\n|$)/i },
        { key: "email", regex: /E-?mail(?:\s+do\s+Solicitante)?\s*:\s*(\S+@\S+)/i },
        { key: "email", regex: /Solicitante\s*:\s*(\S+@\S+)/i },
        { key: "tipo", regex: /Tipo\s+(?:principal|de\s+Requisi[çc][ãa]o)\s*:\s*(.+?)(?:\s{2,}|\n|$)/i },
        { key: "categoria", regex: /Categoria\s+de\s+\w+\s*:\s*(.+?)(?:\s{2,}|\n|$)/i },
      ];
      for (const { key, regex } of patterns) {
        if (result[key]) continue;
        const match = text.match(regex);
        if (match?.[1]) result[key] = match[1].trim();
      }
      if (!result.email) {
        const solMatch = text.match(/Solicitante\s*:\s*(.+?)(?:\s{2,}|\n|E-?mail)/i);
        if (solMatch?.[1]) result.email = solMatch[1].trim();
      }
      return result;
    }

    // Process tickets
    const tickets = allIssues.map((issue) => {
      const created = new Date(issue.fields.created);
      const resolved = issue.fields.resolutiondate ? new Date(issue.fields.resolutiondate) : null;

      let resolutionTimeHours: number | null = null;
      if (resolved && !isNaN(created.getTime()) && !isNaN(resolved.getTime())) {
        resolutionTimeHours = Math.round((resolved.getTime() - created.getTime()) / (1000 * 60 * 60) * 10) / 10;
      }

      const descText = extractAdfText(issue.fields.description);
      const parsed = parseDescription(descText);

      const setor = extractCustomField(issue.fields["customfield_10060"]) 
        || extractCustomField(issue.fields["customfield_10061"]) 
        || extractCustomField(issue.fields["customfield_10068"])
        || parsed.setor;

      const solicitanteEmail = (issue.fields["customfield_10002"] as { emailAddress?: string })?.emailAddress
        ?? (issue.fields.reporter as { emailAddress?: string } | null)?.emailAddress
        ?? parsed.email;

      const tipoRequisicao = extractCustomField(issue.fields["customfield_10010"]) || parsed.tipo;

      return {
        key: issue.key,
        summary: issue.fields.summary,
        status: issue.fields.status?.name ?? "Unknown",
        priority: issue.fields.priority?.name ?? "Medium",
        assignee: issue.fields.assignee?.displayName ?? "Não atribuído",
        tipoDispositivo: issue.fields.issuetype?.name ?? "",
        createdAt: issue.fields.created,
        resolvedAt: issue.fields.resolutiondate,
        resolutionTimeHours,
        description: descText,
        setor,
        solicitanteEmail,
        tipoRequisicao,
        categoriaHardware: parsed.categoria,
      };
    });

    // Aggregate metrics
    const totalTickets = tickets.length;

    const resolvedTickets = tickets.filter((t) => t.resolutionTimeHours !== null);
    const avgResolutionHours =
      resolvedTickets.length > 0
        ? Math.round((resolvedTickets.reduce((s, t) => s + t.resolutionTimeHours!, 0) / resolvedTickets.length) * 10) / 10
        : 0;

    const statusMap: Record<string, number> = {};
    tickets.forEach((t) => {
      statusMap[t.status] = (statusMap[t.status] || 0) + 1;
    });

    const slaTargetHours = 48;
    const withinSla = resolvedTickets.filter((t) => t.resolutionTimeHours! <= slaTargetHours).length;
    const slaCompliance = resolvedTickets.length > 0 ? Math.round((withinSla / resolvedTickets.length) * 100) : 0;

    const priorityMap: Record<string, number> = {};
    tickets.forEach((t) => {
      priorityMap[t.priority] = (priorityMap[t.priority] || 0) + 1;
    });

    const result = {
      totalTickets,
      avgResolutionHours,
      slaCompliance,
      statusBreakdown: statusMap,
      priorityBreakdown: priorityMap,
      jiraBaseUrl: baseUrl,
      tickets,
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error", message: String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
