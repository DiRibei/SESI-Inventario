
-- Allow patrimonio to be nullable
ALTER TABLE public.peripheral_items ALTER COLUMN patrimonio DROP NOT NULL;

-- Drop old unique constraint on patrimonio
ALTER TABLE public.peripheral_items DROP CONSTRAINT IF EXISTS peripheral_items_patrimonio_key;

-- Add partial unique index (only enforce uniqueness for non-null values)
CREATE UNIQUE INDEX IF NOT EXISTS peripheral_items_patrimonio_unique ON public.peripheral_items (patrimonio) WHERE patrimonio IS NOT NULL;
