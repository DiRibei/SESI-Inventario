
CREATE TABLE public.peripheral_models (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  brand TEXT NOT NULL,
  model_name TEXT NOT NULL,
  category TEXT NOT NULL,
  unit_price DOUBLE PRECISION,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.peripheral_models ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view peripheral models" ON public.peripheral_models FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can insert peripheral models" ON public.peripheral_models FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update peripheral models" ON public.peripheral_models FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete peripheral models" ON public.peripheral_models FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.peripheral_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  model_id UUID NOT NULL REFERENCES public.peripheral_models(id) ON DELETE CASCADE,
  patrimonio TEXT NOT NULL UNIQUE,
  serial TEXT,
  status TEXT NOT NULL DEFAULT 'Disponível',
  colaborador TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.peripheral_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view peripheral items" ON public.peripheral_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert peripheral items" ON public.peripheral_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated can update peripheral items" ON public.peripheral_items FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admins can delete peripheral items" ON public.peripheral_items FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
