-- Teardown of internal Lovable Cloud backend
-- The app uses an external Supabase instance, so these internal tables/functions are unused.

-- Drop tables (CASCADE removes policies, indexes, FKs)
DROP TABLE IF EXISTS public.HistoricoAtivos CASCADE;
DROP TABLE IF EXISTS public."HistoricoAtivos" CASCADE;
DROP TABLE IF EXISTS public."EstoqueSolvis" CASCADE;
DROP TABLE IF EXISTS public."Colaboradores" CASCADE;
DROP TABLE IF EXISTS public.peripheral_items CASCADE;
DROP TABLE IF EXISTS public.peripheral_models CASCADE;
DROP TABLE IF EXISTS public.peripherals CASCADE;
DROP TABLE IF EXISTS public.spare_parts CASCADE;
DROP TABLE IF EXISTS public.user_roles CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;

-- Drop functions
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.update_spare_parts_updated_at() CASCADE;
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role) CASCADE;

-- Drop enum type
DROP TYPE IF EXISTS public.app_role CASCADE;