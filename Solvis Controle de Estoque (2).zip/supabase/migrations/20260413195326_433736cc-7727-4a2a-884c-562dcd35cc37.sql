ALTER TABLE public."Colaboradores" ADD COLUMN IF NOT EXISTS email text;
CREATE INDEX IF NOT EXISTS idx_colaboradores_email ON public."Colaboradores" (email);