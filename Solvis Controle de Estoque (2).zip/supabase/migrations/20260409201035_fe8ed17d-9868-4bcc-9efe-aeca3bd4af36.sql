
CREATE TABLE public.peripherals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  model_name TEXT NOT NULL,
  category TEXT NOT NULL,
  patrimonio TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'Disponível',
  colaborador TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.peripherals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view peripherals"
ON public.peripherals FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Authenticated can insert peripherals"
ON public.peripherals FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated can update peripherals"
ON public.peripherals FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Admins can delete peripherals"
ON public.peripherals FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_peripherals_updated_at
BEFORE UPDATE ON public.peripherals
FOR EACH ROW
EXECUTE FUNCTION public.update_spare_parts_updated_at();
