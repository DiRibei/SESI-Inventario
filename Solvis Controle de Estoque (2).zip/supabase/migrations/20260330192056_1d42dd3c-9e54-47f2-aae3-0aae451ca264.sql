
-- Remove overly permissive anon insert on HistoricoAtivos (only authenticated should insert)
DROP POLICY IF EXISTS "Anon can insert history" ON public."HistoricoAtivos";
