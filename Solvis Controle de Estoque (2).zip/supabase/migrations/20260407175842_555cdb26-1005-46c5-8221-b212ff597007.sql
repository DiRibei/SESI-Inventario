ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS user_roles TEXT DEFAULT NULL;

-- Migrate existing data from user_roles table into profiles.user_roles
UPDATE public.profiles p
SET user_roles = ur.role::text
FROM public.user_roles ur
WHERE p.user_id = ur.user_id
AND p.user_roles IS NULL;