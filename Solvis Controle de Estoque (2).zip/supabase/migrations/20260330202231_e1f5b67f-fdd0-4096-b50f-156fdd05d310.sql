
CREATE TABLE public."EstoqueSolvis" (
  "Patrimônio" text PRIMARY KEY,
  "Categoria" text,
  "Marca" text,
  "modelo" text,
  "serial" text,
  "Unidade" text,
  "Status" text,
  "Valor" float8 DEFAULT 0,
  "Atualizado_Em" timestamptz,
  "Colaborador" text,
  "observacoes" text
);

ALTER TABLE public."EstoqueSolvis" ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view assets" ON public."EstoqueSolvis"
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert assets" ON public."EstoqueSolvis"
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update assets" ON public."EstoqueSolvis"
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Admins can delete assets" ON public."EstoqueSolvis"
  FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anon can view assets" ON public."EstoqueSolvis"
  FOR SELECT TO anon USING (true);
