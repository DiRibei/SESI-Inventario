# Migração: Forms/Sheets → Supabase + n8n

Este guia tem **duas ações manuais** no Supabase e no n8n. O app já está pronto.

---

## 1) Supabase (projeto legado `kdhjbtyjiaegsjvpyhqs`)

Cole e execute o SQL abaixo no **SQL Editor** do projeto Supabase usado pelo app. Ele cria a tabela `chamados`, RLS e trigger de `updated_at`. Usa o `has_role` que já existe no projeto.

```sql
CREATE TABLE IF NOT EXISTS public.chamados (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  nome            TEXT NOT NULL,
  email           TEXT NOT NULL,
  setor           TEXT NOT NULL,
  tipo            TEXT NOT NULL CHECK (tipo IN ('INCIDENTE','REQUISIÇÃO','ACESSO OU REVOGAÇÃO')),
  hardware        TEXT,
  software        TEXT,
  outros          TEXT,
  descricao_req   TEXT,
  autorizador     TEXT,
  aplicativos     TEXT[],
  descricao       TEXT NOT NULL,
  urgencia        TEXT NOT NULL CHECK (urgencia IN ('BAIXA','MÉDIA','ALTA','ALTÍSSIMA')),
  status          TEXT NOT NULL DEFAULT 'pendente'
                  CHECK (status IN ('pendente','processando','enviado','erro')),
  jira_issue_key  TEXT,
  jira_issue_url  TEXT,
  erro            TEXT,
  processado_em   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_chamados_pendentes ON public.chamados (created_at) WHERE status = 'pendente';
CREATE INDEX IF NOT EXISTS idx_chamados_user      ON public.chamados (user_id, created_at DESC);

GRANT SELECT, INSERT ON public.chamados TO authenticated;
GRANT ALL ON public.chamados TO service_role;

ALTER TABLE public.chamados ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuario cria proprio chamado"
  ON public.chamados FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuario le proprio chamado"
  ON public.chamados FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Sem policy de admin: o projeto legado não tem a infra de RBAC (app_role/has_role).
-- Admin lê os chamados via SQL Editor ou via service_role (que bypassa RLS).
-- Se no futuro precisar de uma tela "Todos os chamados" no app, adicionar policy
-- por e-mail: USING (auth.jwt()->>'email' = 'diego.ferreira@solvis.com.br').

CREATE OR REPLACE FUNCTION public.touch_chamados_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS trg_chamados_updated_at ON public.chamados;
CREATE TRIGGER trg_chamados_updated_at
  BEFORE UPDATE ON public.chamados
  FOR EACH ROW EXECUTE FUNCTION public.touch_chamados_updated_at();
```

> O n8n vai precisar da `service_role key` do projeto pra ler/atualizar (bypass RLS). Pegue em **Project Settings → API → service_role**.

---

## 2) n8n — ajustar o workflow existente

A lógica continua igual: trigger 1×/min → pega pendentes → marca processado → switch por tipo → cria issue no Jira → e-mail pro solicitante e pro time de TI.

Só **trocam-se as duas pontas de Google Sheets por Postgres** e **as expressões de campo passam a usar snake_case**.

### 2.1 Substituir o nó "Lendo todos os chamados do form" (Google Sheets) por **Postgres → Execute Query**

Credencial: criar uma nova **Postgres** usando o **Transaction Pooler (Supavisor)** do Supabase — o host direto (`db.<ref>.supabase.co`) só resolve em IPv6 e o n8n Cloud não tem rota IPv6, então falha com `ENETUNREACH ...:5432`. O pooler é IPv4 e é o método recomendado para integrações externas.

Pegue os valores exatos em **Project Settings → Database → Connection string → aba "Transaction pooler"** e preencha:

- **Host**: `aws-1-sa-east-1.pooler.supabase.com` (copie do painel — a região pode variar)
- **Port**: `6543` (Transaction pooler)
- **Database**: `postgres`
- **User**: `postgres.kdhjbtyjiaegsjvpyhqs` (formato `postgres.<project-ref>` é obrigatório no pooler)
- **Password**: senha do banco (a mesma do Project Settings → Database)
- **SSL**: `allow` (ou `require`)
- **Ignore SSL Issues (Insecure)**: **ON** — sem isso o n8n falha com `self-signed certificate in certificate chain` (o CA do Supavisor não está na cadeia padrão do Node; o n8n Cloud não permite carregar CA customizado). A conexão segue criptografada por TLS, só pula a verificação do certificado — aceitável porque o host é fixo e conhecido.
- **SSH Tunnel**: OFF (o pooler é público IPv4, não precisa de túnel)
- **Maximum number of connections**: vazio ou `5` (workflow roda 1×/min com queries curtas)

> Por que pooler e não direto: o host direto só tem AAAA (IPv6); n8n Cloud roda em rede sem IPv6 → `ENETUNREACH`. O Transaction pooler (6543) atende IPv4 e é ideal pro workflow, que só faz queries curtas (sem `LISTEN/NOTIFY` nem transações longas). Se um dia precisar de session features, troque para o Session pooler na porta `5432` do mesmo host.

Query do nó:

```sql
SELECT id, nome, email, setor, tipo,
       hardware, software, outros,
       descricao_req, autorizador, aplicativos,
       descricao, urgencia, created_at
FROM public.chamados
WHERE status = 'pendente'
ORDER BY created_at ASC
LIMIT 50;
```

> Pode apagar o nó **"Pegando Linhas não processadas"** (Filter) — o `WHERE status = 'pendente'` já filtra.

### 2.2 Novo nó **`Postgres - Lock`** (UPDATE para `processando`)

Substitui o antigo "Marcando chamado como processado" (Google Sheets).

- **Tipo:** Postgres → Execute Query
- **Posição no fluxo:** **imediatamente após `Postgres - Pendentes`**, antes dos e-mails e antes do switch de tipo.
- **Settings → Execute Once per Item:** **ON**. Isso garante que o nó rode 1× por chamado retornado, em vez de 1× só pra primeira linha.
- **Query:**

  ```sql
  UPDATE public.chamados
  SET status = 'processando'
  WHERE id = '{{ $json.id }}' AND status = 'pendente'
  RETURNING id;
  ```

Aqui `$json.id` funciona porque o item ainda vem direto de `Postgres - Pendentes` (nenhum nó intermediário transformou os dados).

**Por que o lock vem antes dos e-mails:** se algum nó posterior (e-mail, Jira) falhar, o chamado fica em `processando` e **não é reprocessado** no próximo tick do Schedule. Sem isso, uma falha intermitente reenviaria e-mails e abriria issues duplicadas no Jira.

> **Versão simplificada (sem dedupe):** se você aceita o risco de duplicação em caso de falha, pode pular este passo 2.2 e deixar só o UPDATE final do passo 2.3 (que já marca como `enviado`). Mais simples, porém sem proteção contra reenvio.

### 2.3 Novo nó **`Postgres - Concluir`** ao final de cada ramo do Jira

Um nó Postgres no fim de **cada** ramo, depois do nó que cria a issue no Jira (`hardware`, `software`, `Requisição`, `Acesso/Revogação`).

- **Tipo:** Postgres → Execute Query
- **Execute Once per Item:** ON
- **Query:**

  ```sql
  UPDATE public.chamados
  SET status         = 'enviado',
      jira_issue_key = '{{ $json.key }}',
      jira_issue_url = 'https://SEU_DOMINIO.atlassian.net/browse/{{ $json.key }}',
      processado_em  = now()
  WHERE id = '{{ $('Postgres - Pendentes').item.json.id }}';
  ```

**Atenção às duas referências diferentes no mesmo SQL:**

- `{{ $json.key }}` → aqui `$json` é a **resposta do nó Jira anterior** (que contém `key`, `self`, `id`).
- `{{ $('Postgres - Pendentes').item.json.id }}` → precisa puxar do nó de leitura, porque depois do Jira o `$json` não tem mais o id da linha do banco.

Se renomear o nó de leitura, ajuste o nome entre aspas.

### 2.4 Atualizar as expressões dos campos nos nós existentes

De-para (Sheets → Postgres):

| Antes (Sheets)                                                                                       | Depois (Postgres)              |
| ---------------------------------------------------------------------------------------------------- | ------------------------------ |
| `$json['Primeiramente, diga seu nome:']`                                                             | `$json.nome`                   |
| `$json['Endereço de e-mail']`                                                                        | `$json.email`                  |
| `$json['E qual seu setor?']`                                                                         | `$json.setor`                  |
| `$json['O que você precisa?']`                                                                       | `$json.tipo`                   |
| `$json['Caso seu problema seja HARDWARE:']`                                                          | `$json.hardware`               |
| `$json['Caso seu problema seja SOFTWARE']`                                                           | `$json.software`               |
| `$json['Caso tenha escolhido "Outros", fale qual:']`                                                 | `$json.outros`                 |
| `$json['Descreva em detalhes de qual o equipamento você precisa, a quantidade (se for mais de um) e por quê.']` | `$json.descricao_req` |
| `$json['Quem autorizou sua solicitação:']`                                                           | `$json.autorizador`            |
| `$json['Você precisa de acesso, ou exclusão, a qual aplicativo?']`                                  | `{{ ($json.aplicativos || []).join(', ') }}` |
| `$json['Descreva, em detalhes, o que está havendo:']`                                                | `$json.descricao`              |
| `$json['Qual sua urgência?']`                                                                        | `$json.urgencia`               |
| `$json['Carimbo de data/hora']`                                                                      | `$json.created_at`             |

**Regra geral pra decidir entre `$json.<campo>` e `$('Postgres - Pendentes').item.json.<campo>`:**

- Nó está **logo depois** de `Postgres - Pendentes` ou `Postgres - Lock` (ex.: e-mails, switch de tipo)? Use `$json.<campo>` — o item ainda é a linha do banco.
- Nó está **depois do Jira** (ex.: `Postgres - Concluir`)? Use `$('Postgres - Pendentes').item.json.<campo>` — porque `$json` agora é a resposta do Jira.

### 2.5 Conexões finais do workflow

No n8n cada conexão é literal: a **saída** de um nó vai para a **entrada** do próximo. Os nós abaixo ficam **em série** (não em paralelo); cada `→` é uma aresta.

```text
Schedule Trigger (1/min)
  → Postgres - Pendentes
  → Postgres - Lock                 (Execute Once per Item)
  → Send a message                  (e-mail ao solicitante)
  → Send a message1                 (alerta TI)
  → Switch "tipo"
       ├─ INCIDENTE          → Switch hardware/software
       │                          ├─ hardware → Jira - Hardware    → Postgres - Concluir
       │                          └─ software → Jira - Software    → Postgres - Concluir
       ├─ REQUISIÇÃO         → Jira - Requisição                    → Postgres - Concluir
       └─ ACESSO/REVOGAÇÃO   → Jira - Acesso                        → Postgres - Concluir
```

Os e-mails só rodam **depois** do `Postgres - Lock` ter confirmado a posse do chamado — assim, se o lock não atualizou nenhuma linha (porque outro tick já pegou o chamado), os e-mails não disparam de novo.



---

## 3) App

Já está pronto. O formulário agora insere direto na tabela `chamados` (status=`pendente`) e o n8n cuida do resto.

## 4) Validação

1. Rode o SQL no Supabase.
2. Atualize o n8n e ative o workflow.
3. No app, abra um chamado de teste.
4. No SQL Editor: `SELECT id, status, jira_issue_key, processado_em FROM public.chamados ORDER BY created_at DESC LIMIT 5;` — em até 1 minuto deve ir pra `enviado` com a key do Jira.
