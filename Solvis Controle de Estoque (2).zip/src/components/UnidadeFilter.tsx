import { Building2, Factory } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export type UnidadeFilterValue = "Todos" | "Matriz" | "Fábrica";

interface UnidadeFilterProps {
  value: UnidadeFilterValue;
  onChange: (value: UnidadeFilterValue) => void;
}

const OPTIONS: { value: UnidadeFilterValue; label: string; icon: React.ReactNode }[] = [
  { value: "Todos", label: "Todas Unidades", icon: null },
  { value: "Matriz", label: "Matriz", icon: <Building2 className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" /> },
  { value: "Fábrica", label: "Fábrica", icon: <Factory className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" /> },
];

export function UnidadeFilter({ value, onChange }: UnidadeFilterProps) {
  return (
    <Select value={value} onValueChange={(v) => onChange(v as UnidadeFilterValue)}>
      <SelectTrigger className="w-[170px]">
        <Building2 className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {OPTIONS.map((o) => (
          <SelectItem key={o.value} value={o.value}>
            <span className="flex items-center">
              {o.icon}
              {o.label}
            </span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
